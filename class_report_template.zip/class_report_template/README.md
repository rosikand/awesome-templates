# Class Project Report Template

This is a cleaned LaTeX template forked from the original project report format.
All project-specific text, results, figures, and bibliography entries have been removed.

## Files

- `main.tex` — main report file, packages, metadata, abstract, section includes
- `content/` — section files for introduction, related work, methods, results, conclusion, and appendix
- `figures/` — place report figures here
- `refs.bib` — add BibTeX references here
- `neurips_2020.sty` — preserved style file from the original report format

## Build

Basic build:

```bash
pdflatex main.tex
```

If you use references, uncomment the bibliography block in `main.tex`, add entries to `refs.bib`, and run:

```bash
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

## Common edits

- Change the title and author block in `main.tex`.
- Replace the TODO comments in `content/*.tex` with your report content.
- Add figures to `figures/` and include them with `\includegraphics{figures/your_figure.png}`.
- Uncomment the appendix block in `main.tex` if needed.
